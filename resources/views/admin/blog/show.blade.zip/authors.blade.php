@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div><span class="ml-admin-eyebrow">BLOG</span><h1>Authors & Reviewers</h1><p>Manage the people credited with creating and reviewing content.</p></div>
    </div>

    <div class="ml-admin-simple-grid">
        <section class="ml-admin-blog-form-card">
            <form method="POST" action="{{ route('admin.blog.authors.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="ml-admin-blog-form-section">
                    <div class="ml-admin-blog-section-title"><strong>Add Author</strong><span>Create an author or reviewer profile</span></div>
                    <label>Name</label><input name="name" required>
                    <label>Role</label><input name="role">
                    <label>Bio</label><textarea name="bio" rows="4"></textarea>
                    <label>Photo</label><input name="image" type="text" placeholder="img/blog/authors/name.webp">
                    <label class="ml-admin-check"><input type="checkbox" name="is_active" value="1" checked><span>Active</span></label>
                    <button class="ml-admin-blog-primary" type="submit">Add Author</button>
                </div>
            </form>
        </section>

        <section class="ml-admin-blog-table-card">
            <div class="ml-admin-blog-table-head"><strong>Existing Authors</strong></div>
            <div class="ml-admin-blog-table-wrap">
                <table class="ml-admin-blog-table">
                    <thead><tr><th>Name</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    @foreach($authors as $author)
                        <tr>
                            <td><strong>{{ $author->name }}</strong></td><td>{{ $author->role ?? '—' }}</td>
                            <td><span class="ml-admin-blog-status {{ $author->is_active ? 'published' : 'draft' }}">{{ $author->is_active ? 'Active' : 'Inactive' }}</span></td>
                            <td><div class="ml-admin-blog-actions"><a href="#"><i class="bi bi-pencil"></i></a><form method="POST" action="{{ route('admin.blog.authors.destroy', $author) }}">@csrf @method('DELETE')<button onclick="return confirm('Delete this author?')"><i class="bi bi-trash3"></i></button></form></div></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
@endsection

@push('styles')<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">@endpush
