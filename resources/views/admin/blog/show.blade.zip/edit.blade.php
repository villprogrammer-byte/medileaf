@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div>
            <span class="ml-admin-eyebrow">BLOG</span>
            <h1>Edit Post</h1>
            <p>Update article content, publishing and SEO settings.</p>
        </div>
        <a href="{{ route('admin.blog.index') }}" class="ml-admin-blog-secondary">
            <i class="bi bi-arrow-left"></i> All Posts
        </a>
    </div>

    <form method="POST" action="{{ route('admin.blog.update', $blogPost) }}" enctype="multipart/form-data" class="ml-admin-blog-form-card">
        @csrf
        @method('PUT')
        @include('admin.blog.partials.form', ['post' => $blogPost])
    </form>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">
@endpush
