@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div>
            <span class="ml-admin-eyebrow">BLOG</span>
            <h1>Add New Post</h1>
            <p>Create a new SEO-ready MediLeaf article.</p>
        </div>
        <a href="{{ route('admin.blog.index') }}" class="ml-admin-blog-secondary">
            <i class="bi bi-arrow-left"></i> All Posts
        </a>
    </div>

    <form method="POST" action="{{ route('admin.blog.store') }}" enctype="multipart/form-data" class="ml-admin-blog-form-card">
        @csrf
        @include('admin.blog.partials.form')
    </form>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">
@endpush
