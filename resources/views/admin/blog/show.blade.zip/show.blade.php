@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div><span class="ml-admin-eyebrow">BLOG POST</span><h1>{{ $blogPost->title }}</h1><p>Admin preview of this article.</p></div>
        <a href="{{ route('admin.blog.edit', $blogPost) }}" class="ml-admin-blog-primary"><i class="bi bi-pencil"></i> Edit Post</a>
    </div>
    <div class="ml-admin-blog-form-card ml-admin-blog-preview">
        {!! $blogPost->content !!}
    </div>
</div>
@endsection

@push('styles')<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">@endpush
