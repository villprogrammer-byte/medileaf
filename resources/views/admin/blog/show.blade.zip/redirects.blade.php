@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div><span class="ml-admin-eyebrow">SEO</span><h1>Blog Redirects</h1><p>Keep changed article URLs safely redirected.</p></div>
    </div>

    <div class="ml-admin-simple-grid">
        <section class="ml-admin-blog-form-card">
            <form method="POST" action="{{ route('admin.blog.redirects.store') }}">
                @csrf
                <div class="ml-admin-blog-form-section">
                    <div class="ml-admin-blog-section-title"><strong>Add Redirect</strong><span>Use a 301 redirect for changed slugs</span></div>
                    <label>Old Path</label><input name="old_path" placeholder="/blog/old-slug" required>
                    <label>New Path</label><input name="new_path" placeholder="/blog/new-slug" required>
                    <label>Status Code</label><select name="status_code"><option value="301">301 Permanent</option><option value="302">302 Temporary</option></select>
                    <button class="ml-admin-blog-primary" type="submit">Add Redirect</button>
                </div>
            </form>
        </section>

        <section class="ml-admin-blog-table-card">
            <div class="ml-admin-blog-table-head"><strong>Existing Redirects</strong></div>
            <div class="ml-admin-blog-table-wrap">
                <table class="ml-admin-blog-table">
                    <thead><tr><th>From</th><th>To</th><th>Code</th><th>Actions</th></tr></thead>
                    <tbody>
                    @foreach($redirects as $redirect)
                        <tr>
                            <td>{{ $redirect->old_path }}</td><td>{{ $redirect->new_path }}</td><td>{{ $redirect->status_code }}</td>
                            <td><div class="ml-admin-blog-actions"><form method="POST" action="{{ route('admin.blog.redirects.destroy', $redirect) }}">@csrf @method('DELETE')<button onclick="return confirm('Delete this redirect?')"><i class="bi bi-trash3"></i></button></form></div></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
@endsection

@push('styles')<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">@endpush
