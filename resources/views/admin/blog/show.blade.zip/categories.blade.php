@extends('admin.layouts.app')

@section('title', 'Blog')

@section('content')
<div class="ml-admin-blog-page">
    <div class="ml-admin-blog-header">
        <div><span class="ml-admin-eyebrow">BLOG</span><h1>Categories</h1><p>Organise your health content.</p></div>
    </div>

    <div class="ml-admin-simple-grid">
        <section class="ml-admin-blog-form-card">
            <form method="POST" action="{{ route('admin.blog.categories.store') }}">
                @csrf
                <div class="ml-admin-blog-form-section">
                    <div class="ml-admin-blog-section-title"><strong>Add Category</strong><span>Create a new content category</span></div>
                    <label>Name</label><input name="name" required>
                    <label>Slug</label><input name="slug">
                    <label>Description</label><textarea name="description" rows="4"></textarea>
                    <label class="ml-admin-check"><input type="checkbox" name="is_active" value="1" checked><span>Active</span></label>
                    <button class="ml-admin-blog-primary" type="submit">Add Category</button>
                </div>
            </form>
        </section>

        <section class="ml-admin-blog-table-card">
            <div class="ml-admin-blog-table-head"><strong>Existing Categories</strong></div>
            <div class="ml-admin-blog-table-wrap">
                <table class="ml-admin-blog-table">
                    <thead><tr><th>Name</th><th>Slug</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    @foreach($categories as $category)
                        <tr>
                            <td><strong>{{ $category->name }}</strong></td>
                            <td>{{ $category->slug }}</td>
                            <td><span class="ml-admin-blog-status {{ $category->is_active ? 'published' : 'draft' }}">{{ $category->is_active ? 'Active' : 'Inactive' }}</span></td>
                            <td>
                                <div class="ml-admin-blog-actions">
                                    <a href="{{ route('admin.blog.categories') }}#category-{{ $category->id }}"><i class="bi bi-pencil"></i></a>
                                    <form method="POST" action="{{ route('admin.blog.categories.destroy', $category) }}" onsubmit="return confirm('Delete this category?')">@csrf @method('DELETE')<button><i class="bi bi-trash3"></i></button></form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
@endsection

@push('styles')<link rel="stylesheet" href="{{ asset('css/admin-blog.css') }}">@endpush
